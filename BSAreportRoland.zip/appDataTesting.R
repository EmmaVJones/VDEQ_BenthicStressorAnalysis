source('global.R')
#source('global_appModules.R')
source('global_appModules_new.R')
source('global_logiManipulationModule.R')
source('global_finalReportModule.R')



# Upload GIS data here to avoid uploading it twice (if it were in the global.R file)
#eco <- readOGR('data','vaECOREGIONlevel3__proj84')
#supaB <- readOGR('data','VAsuperbasins_proj84')
eco <- st_read('data/vaECOREGIONlevel3__proj84.shp')
supaB <- st_read('data/VAsuperbasins_proj84.shp')

siteData <- removeUnits_envDataDF(read.csv('C:/HardDriveBackup/R/GitHub/BenthicStressorAnalysiswithLogi/testData/4ADEE000.06/LOGImanipulatedData_2020-10-294ADEE000.06.csv')) 

# Deal with columns of only NA coming in as logical
dat <- siteData %>% select(-(Temp))
dat <- japply( dat, which(sapply(dat, class)=="logical"), as.numeric )

datamean <- select(dat,-c(StationID,CollectionDateTime,Longitude,Latitude))%>%
  summarise_all(funs(format(mean(., na.rm = TRUE),digits=4)))%>%mutate(Statistic="Average")
datamean[datamean %in% c("NaN","NA")] <- NA
datamedian <- select(dat,-c(StationID,CollectionDateTime,Longitude,Latitude))%>%
  summarise_all(funs(format(median(., na.rm = TRUE),digits=4)))%>%mutate(Statistic="Median")
datamedian[datamedian %in% c("NaN","NA")] <- NA
stats <- rbind(datamean,datamedian)%>%select(Statistic,everything())
 
Basin <- 'Roanoke Basin'
Ecoregion <- 'Blue Ridge Mountains'
StreamOrder <- 'Third Order'

percentiles <- list(pH = percentileTable(stats,"pH",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    DO = percentileTable(stats,"DO",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    TN = percentileTable(stats,"TN",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    TP = percentileTable(stats,"TP",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    TotHab = percentileTable(stats,"TotalHabitat",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    LRBS = percentileTable(stats,"LRBS",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    MetalsCCU = percentileTable(stats,"MetalsCCU",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    SpCond = percentileTable(stats,"SpCond",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    TDS = percentileTable(stats,"TDS",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    DSulfate = percentileTable(stats,"DSulfate",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    DChloride = percentileTable(stats,"DChloride",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    DPotassium = percentileTable(stats,"DPotassium",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)),
                    DSodium = percentileTable(stats,"DSodium",Basin,Ecoregion,StreamOrder,unique(siteData$StationID)))